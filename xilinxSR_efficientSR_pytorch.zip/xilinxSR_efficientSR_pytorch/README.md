## [NTIRE 2022 Workshop and Challenge](https://data.vision.ee.ethz.ch/cvl/ntire22/) @ CVPR 2022
## Efficient Super-Resolution Challenge

* Average PSNR on validation data: 29.05 dB

* Average inference time (V100) on validation data: 0.044 second 

    Note: The best average inference time among three trials is selected.

## How to use the code during test phase.
1. Enveriment details
  -Pytorch1.7.1
  -python3.7

2. Put validation/test dataset under the `data` folder
   -  `data` folder structure:
   ```
    data:
        |---DIV2K_valid_LR_bicubic
              |---X4
                    |---0801x4.png
                    |---0802x4.png
                    |......
                    |---0900x4.png

        |---DIV2K_test_LR
              |---0901.png
              |---0902.png
              |......
              |---1000.png
    ```

3. The weight file is under the `model_zoo` folder.

4. Test on the validation set
   ```
   python run_val.py

   ```
4. Test on the test set
   ```
   python run_test.py

   ```



